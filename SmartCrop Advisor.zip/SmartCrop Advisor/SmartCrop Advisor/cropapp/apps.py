from django.apps import AppConfig


class CropappConfig(AppConfig):
    name = 'cropapp'
