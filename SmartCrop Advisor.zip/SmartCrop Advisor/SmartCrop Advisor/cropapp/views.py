from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User
import pandas as pd
import joblib
import os

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report

# Global variables
df = None
x_train = x_test = y_train = y_test = model = None
labels = ['rice', 'maize', 'chickpea', 'kidneybeans', 'pigeonpeas',
          'mothbeans', 'mungbean', 'blackgram', 'lentil', 'pomegranate',
          'banana', 'mango', 'grapes', 'watermelon', 'muskmelon', 'apple',
          'orange', 'papaya', 'coconut', 'cotton', 'jute', 'coffee']

def home(request):
    return render(request, 'home.html')

def admin_login(request):
    if request.method == 'POST':
        uname = request.POST['username']
        pwd = request.POST['password']
        if uname == 'admin' and pwd == 'admin':
            return redirect('admin_dashboard')
        else:
            messages.error(request, "Invalid credentials")
            return redirect('admin_login')
    return render(request, 'adminlogin.html')

def admin_dashboard(request):
    return render(request, 'admin_dashboard.html')

import pandas as pd
from django.shortcuts import render, redirect
from django.contrib import messages

df = None  # Global DataFrame (for demo purposes; better to use sessions or DB in production)

def upload_dataset(request):
    global df
    if request.method == 'POST' and request.FILES.get('dataset'):
        try:
            csv_file = request.FILES['dataset']
            df = pd.read_csv(csv_file)  # Directly read without saving
            messages.success(request, "Dataset uploaded successfully!")
            return redirect('admin_dashboard')  # Redirect to dashboard after upload
        except Exception as e:
            messages.error(request, f"Error reading file: {str(e)}")
            return redirect('upload')
    return render(request, 'upload.html')


def preprocess_data(request):
    global df
    if df is not None:
        nulls = df.isnull().sum()
        dups = df.duplicated().sum()
        df.drop_duplicates(inplace=True)
        df.dropna(inplace=True)
        label_encoder = LabelEncoder()
        df['label'] = label_encoder.fit_transform(df['label'])
        output = f"Null values before: {nulls}<br>Duplicate rows: {dups}<br>Shape after preprocessing: {df.shape}"
        return render(request, 'preprocess.html', {'result': output})
    else:
        return render(request, 'preprocess.html', {'result': "Please upload a dataset first."})

def split_data(request):
    global x_train, x_test, y_train, y_test, df
    if df is not None:
        x = df.iloc[:, :-1]
        y = df.iloc[:, -1]
        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=28)
        return render(request, 'split.html', {'result': f"Train shape: {x_train.shape}, Test shape: {x_test.shape}"})
    else:
        return render(request, 'split.html', {'result': "Please preprocess the data first."})

import os
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from django.shortcuts import render

import os
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from django.shortcuts import render

def train_model(request):
    global model, x_train, y_train, x_test, y_test
    model_path = 'crop_model.pkl'

    if x_train is not None:
        # Ensure directory exists if any (not needed here, but safe)
        os.makedirs(os.path.dirname(model_path) or '.', exist_ok=True)

        # Always train a new model and overwrite the existing one
        model = RandomForestClassifier()
        model.fit(x_train, y_train)

        # Save the newly trained model
        joblib.dump(model, model_path)
        print("Model trained and saved successfully.")

        # Predict and calculate metrics
        preds = model.predict(x_test)
        accuracy = accuracy_score(y_test, preds) * 100
        precision = precision_score(y_test, preds, average='macro') * 100
        recall = recall_score(y_test, preds, average='macro') * 100
        fscore = f1_score(y_test, preds, average='macro') * 100

        return render(request, 'train.html', {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'fscore': fscore
        })

    else:
        return render(request, 'train.html', {'error': 'Please split the data first.'})


    

def register(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        city = request.POST['city']
        state = request.POST['state']
        country = request.POST['country']
        password = request.POST['password']
        confirm = request.POST['confirm_password']

        if password != confirm:
            messages.error(request, "Passwords do not match")
            return redirect('register')

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already exists")
            return redirect('register')

        user = User(
            name=name, email=email, phone=phone,
            city=city, state=state, country=country,
            password=password
        )
        user.save()
        messages.success(request, "Registration successful")
        return redirect('user_login')
    return render(request, 'register.html')

def user_login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        try:
            user = User.objects.get(email=email, password=password)
            request.session['user_id'] = user.id
            return redirect('user_input')
        except User.DoesNotExist:
            messages.error(request, "Invalid credentials")
            return redirect('user_login')
    return render(request, 'userlogin.html')


from django.shortcuts import render
import pandas as pd
import joblib
import os

# Define feature columns used during model training
FEATURE_COLUMNS = ['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']

# Label mapping for model predictions
labels = {
    0: 'Rice', 1: 'Maize', 2: 'Chickpea', 3: 'Kidneybeans', 4: 'Pigeonpeas',
    5: 'Mothbeans', 6: 'Mungbean', 7: 'Blackgram', 8: 'Lentil', 9: 'Pomegranate',
    10: 'Banana', 11: 'Mango', 12: 'Grapes', 13: 'Watermelon', 14: 'Muskmelon',
    15: 'Apple', 16: 'Orange', 17: 'Papaya', 18: 'Coconut', 19: 'Cotton',
    20: 'Jute', 21: 'Coffee'
}


def user_input(request):
    # ✅ Your complete crop_info dictionary (full data pasted by you)
    crop_info = {
        'Rice': {
            'precautions': 'Avoid waterlogging; ensure proper spacing; monitor pests like stem borer.',
            'marketing': 'High demand in local and export markets; popular staple food.',
            'soil_health': 'Test pH; apply lime if acidic. Ensure adequate organic matter.',
            'fertilizers': [
                {'type': 'Urea', 'amount': '50kg/acre', 'timing': 'At sowing'},
                {'type': 'DAP', 'amount': '40kg/acre', 'timing': 'At tillering'}
            ],
            'pesticides': [
                {'type': 'Tricyclazole', 'dose': '1g/L', 'safety': 'Wear gloves and mask'},
                {'type': 'Carbofuran', 'dose': '0.5kg/acre', 'safety': 'Avoid inhalation'}
            ]
        },
        'Maize': {
            'precautions': 'Avoid water stagnation; use disease-resistant varieties.',
            'marketing': 'Good demand for fodder and human consumption.',
            'soil_health': 'Check nitrogen content; apply compost if low.',
            'fertilizers': [
                {'type': 'NPK', 'amount': '60kg/acre', 'timing': 'Sowing'},
                {'type': 'Urea', 'amount': '40kg/acre', 'timing': 'Knee height stage'}
            ],
            'pesticides': [
                {'type': 'Atrazine', 'dose': '2kg/acre', 'safety': 'Wear protective clothing'},
                {'type': 'Chlorpyrifos', 'dose': '1L/acre', 'safety': 'Avoid direct contact'}
            ]
        },
        'Chickpea': {
            'precautions': 'Rotate crops to prevent disease; avoid waterlogging.',
            'marketing': 'High protein pulses; good export value.',
            'soil_health': 'Test phosphorus; apply SSP if deficient.',
            'fertilizers': [
                {'type': 'Single Super Phosphate', 'amount': '50kg/acre', 'timing': 'Sowing'},
                {'type': 'Potash', 'amount': '20kg/acre', 'timing': 'Flowering stage'}
            ],
            'pesticides': [
                {'type': 'Imidacloprid', 'dose': '0.5ml/L', 'safety': 'Use gloves'},
                {'type': 'Carbendazim', 'dose': '1g/L', 'safety': 'Avoid inhalation'}
            ]
        },
        'Kidneybeans': {
            'precautions': 'Ensure proper irrigation; use trellises for support.',
            'marketing': 'Good market for pulses and export.',
            'soil_health': 'Apply lime if pH < 6; enrich with compost.',
            'fertilizers': [
                {'type': 'Urea', 'amount': '30kg/acre', 'timing': 'Sowing'},
                {'type': 'NPK', 'amount': '50kg/acre', 'timing': 'Vegetative stage'}
            ],
            'pesticides': [
                {'type': 'Thiamethoxam', 'dose': '0.3g/L', 'safety': 'Wear gloves'},
                {'type': 'Mancozeb', 'dose': '2g/L', 'safety': 'Avoid inhalation'}
            ]
        },
        'Pigeonpeas': {
            'precautions': 'Use resistant varieties; avoid waterlogging.',
            'marketing': 'High protein content; popular in Indian cuisine.',
            'soil_health': 'Ensure proper phosphorus; apply compost for organic matter.',
            'fertilizers': [
                {'type': 'DAP', 'amount': '50kg/acre', 'timing': 'Sowing'},
                {'type': 'Potash', 'amount': '20kg/acre', 'timing': 'Flowering stage'}
            ],
            'pesticides': [
                {'type': 'Cypermethrin', 'dose': '0.5ml/L', 'safety': 'Use mask and gloves'},
                {'type': 'Chlorpyrifos', 'dose': '1L/acre', 'safety': 'Avoid contact'}
            ]
        },
        'Mothbeans': {
            'precautions': 'Requires sandy soil; ensure proper drainage.',
            'marketing': 'Used as fodder; increasing demand in drought-prone regions.',
            'soil_health': 'Low fertility soils; apply organic compost.',
            'fertilizers': [
                {'type': 'Urea', 'amount': '20kg/acre', 'timing': 'Sowing'},
                {'type': 'NPK', 'amount': '30kg/acre', 'timing': 'Vegetative stage'}
            ],
            'pesticides': [
                {'type': 'Neem oil', 'dose': '5ml/L', 'safety': 'Safe; avoid eye contact'},
                {'type': 'Carbendazim', 'dose': '1g/L', 'safety': 'Avoid inhalation'}
            ]
        },
        'Mungbean': {
            'precautions': 'Avoid excessive irrigation; use disease-free seeds.',
            'marketing': 'High demand for pulses; good export value.',
            'soil_health': 'Ensure potassium adequacy; add compost if needed.',
            'fertilizers': [
                {'type': 'DAP', 'amount': '30kg/acre', 'timing': 'Sowing'},
                {'type': 'MOP', 'amount': '20kg/acre', 'timing': 'Flowering stage'}
            ],
            'pesticides': [
                {'type': 'Imidacloprid', 'dose': '0.5ml/L', 'safety': 'Wear gloves'},
                {'type': 'Mancozeb', 'dose': '2g/L', 'safety': 'Avoid inhalation'}
            ]
        },
        'Blackgram': {
            'precautions': 'Use well-drained soil; rotate crops.',
            'marketing': 'Used in pulses; increasing domestic demand.',
            'soil_health': 'Apply lime if acidic; enrich with organic matter.',
            'fertilizers': [
                {'type': 'Urea', 'amount': '20kg/acre', 'timing': 'Sowing'},
                {'type': 'Potash', 'amount': '20kg/acre', 'timing': 'Flowering'}
            ],
            'pesticides': [
                {'type': 'Neem oil', 'dose': '5ml/L', 'safety': 'Safe; avoid eyes'},
                {'type': 'Chlorpyrifos', 'dose': '1L/acre', 'safety': 'Wear gloves'}
            ]
        },
        'Lentil': {
            'precautions': 'Avoid waterlogging; plant after monsoon.',
            'marketing': 'High protein pulses; export potential.',
            'soil_health': 'Ensure phosphorus adequacy; apply SSP.',
            'fertilizers': [
                {'type': 'Single Super Phosphate', 'amount': '40kg/acre', 'timing': 'Sowing'},
                {'type': 'DAP', 'amount': '20kg/acre', 'timing': 'Vegetative stage'}
            ],
            'pesticides': [
                {'type': 'Carbendazim', 'dose': '1g/L', 'safety': 'Avoid inhalation'},
                {'type': 'Thiamethoxam', 'dose': '0.3g/L', 'safety': 'Wear gloves'}
            ]
        },
        'Pomegranate': {
            'precautions': 'Prune properly; avoid excessive fertilization.',
            'marketing': 'High market demand; export quality fruit.',
            'soil_health': 'Check potassium; improve organic matter.',
            'fertilizers': [
                {'type': 'NPK', 'amount': '50kg/acre', 'timing': 'Pre-flowering'},
                {'type': 'Potash', 'amount': '40kg/acre', 'timing': 'Fruit set'}
            ],
            'pesticides': [
                {'type': 'Emamectin benzoate', 'dose': '5ml/L', 'safety': 'Avoid skin contact'},
                {'type': 'Mancozeb', 'dose': '2g/L', 'safety': 'Wear gloves'}
            ]
        },
        'Banana': {
            'precautions': 'Ensure good drainage; avoid fungal infection.',
            'marketing': 'High demand; suitable for local and export markets.',
            'soil_health': 'Check pH; apply compost regularly.',
            'fertilizers': [
                {'type': 'Urea', 'amount': '100g/plant', 'timing': 'Monthly'},
                {'type': 'Potash', 'amount': '150g/plant', 'timing': 'Monthly'}
            ],
            'pesticides': [
                {'type': 'Bacillus thuringiensis', 'dose': '5ml/L', 'safety': 'Safe for humans'},
                {'type': 'Chlorpyrifos', 'dose': '1L/acre', 'safety': 'Avoid contact'}
            ]
        },
        'Mango': {
            'precautions': 'Prune regularly; monitor pests like mealybugs.',
            'marketing': 'High demand for fresh and processed fruit.',
            'soil_health': 'Apply lime if acidic; enrich soil with compost.',
            'fertilizers': [
                {'type': 'DAP', 'amount': '50kg/acre', 'timing': 'Pre-flowering'},
                {'type': 'NPK', 'amount': '50kg/acre', 'timing': 'Fruit set'}
            ],
            'pesticides': [
                {'type': 'Carbendazim', 'dose': '1g/L', 'safety': 'Wear gloves'},
                {'type': 'Endosulfan', 'dose': '0.5L/acre', 'safety': 'Avoid inhalation'}
            ]
        },
        'Grapes': {
            'precautions': 'Ensure proper trellising; monitor fungal diseases.',
            'marketing': 'Good export potential; high juice demand.',
            'soil_health': 'Ensure potassium and organic matter adequacy.',
            'fertilizers': [
                {'type': 'Potash', 'amount': '50kg/acre', 'timing': 'Pre-flowering'},
                {'type': 'Urea', 'amount': '40kg/acre', 'timing': 'Berry formation'}
            ],
            'pesticides': [
                {'type': 'Sulfur', 'dose': '3g/L', 'safety': 'Wear gloves and mask'},
                {'type': 'Mancozeb', 'dose': '2g/L', 'safety': 'Avoid inhalation'}
            ]
        },
        'Watermelon': {
            'precautions': 'Ensure sandy loam soil; prevent water stagnation.',
            'marketing': 'High local demand; good for summer season.',
            'soil_health': 'Maintain pH 6-7; add compost.',
            'fertilizers': [
                {'type': 'NPK', 'amount': '60kg/acre', 'timing': 'Sowing'},
                {'type': 'Potash', 'amount': '40kg/acre', 'timing': 'Flowering stage'}
            ],
            'pesticides': [
                {'type': 'Imidacloprid', 'dose': '0.5ml/L', 'safety': 'Wear gloves'},
                {'type': 'Carbendazim', 'dose': '1g/L', 'safety': 'Avoid inhalation'}
            ]
        },
        'Muskmelon': {
            'precautions': 'Plant in warm climate; use trellises for vines.',
            'marketing': 'Good local market; limited export potential.',
            'soil_health': 'Ensure sandy loam; maintain organic matter.',
            'fertilizers': [
                {'type': 'Urea', 'amount': '50kg/acre', 'timing': 'Sowing'},
                {'type': 'DAP', 'amount': '30kg/acre', 'timing': 'Vegetative stage'}
            ],
            'pesticides': [
                {'type': 'Neem oil', 'dose': '5ml/L', 'safety': 'Safe; avoid eyes'},
                {'type': 'Chlorpyrifos', 'dose': '1L/acre', 'safety': 'Wear gloves'}
            ]
        },
        'Apple': {
            'precautions': 'Prune regularly; monitor aphids and fungi.',
            'marketing': 'High export demand; popular fruit.',
            'soil_health': 'Apply lime if acidic; compost regularly.',
            'fertilizers': [
                {'type': 'NPK', 'amount': '50kg/acre', 'timing': 'Pre-flowering'},
                {'type': 'Urea', 'amount': '30kg/acre', 'timing': 'Fruit set'}
            ],
            'pesticides': [
                {'type': 'Carbendazim', 'dose': '1g/L', 'safety': 'Wear gloves'},
                {'type': 'Thiophanate-methyl', 'dose': '1g/L', 'safety': 'Avoid inhalation'}
            ]
        },
        'Orange': {
            'precautions': 'Ensure proper drainage; prevent citrus canker.',
            'marketing': 'High juice demand; export potential.',
            'soil_health': 'Maintain pH 6-7; organic matter needed.',
            'fertilizers': [
                {'type': 'DAP', 'amount': '50kg/acre', 'timing': 'Pre-flowering'},
                {'type': 'Potash', 'amount': '40kg/acre', 'timing': 'Fruit set'}
            ],
            'pesticides': [
                {'type': 'Endosulfan', 'dose': '0.5L/acre', 'safety': 'Avoid inhalation'},
                {'type': 'Imidacloprid', 'dose': '0.5ml/L', 'safety': 'Wear gloves'}
            ]
        },
        'Papaya': {
            'precautions': 'Plant in sunny area; avoid waterlogging.',
            'marketing': 'High demand for fresh fruit and juice.',
            'soil_health': 'Maintain pH 6-7; compost regularly.',
            'fertilizers': [
                {'type': 'NPK', 'amount': '50kg/acre', 'timing': 'Monthly'},
                {'type': 'Urea', 'amount': '30kg/acre', 'timing': 'Monthly'}
            ],
            'pesticides': [
                {'type': 'Carbendazim', 'dose': '1g/L', 'safety': 'Avoid inhalation'},
                {'type': 'Neem oil', 'dose': '5ml/L', 'safety': 'Safe; avoid eyes'}
            ]
        },
        'Coconut': {
            'precautions': 'Provide well-drained soil; irrigate regularly.',
            'marketing': 'High demand for oil and water; good export.',
            'soil_health': 'Maintain pH 5.5-7; add compost.',
            'fertilizers': [
                {'type': 'MOP', 'amount': '50kg/acre', 'timing': 'Monthly'},
                {'type': 'DAP', 'amount': '50kg/acre', 'timing': 'Monthly'}
            ],
            'pesticides': [
                {'type': 'Quinalphos', 'dose': '0.5L/acre', 'safety': 'Wear gloves'},
                {'type': 'Endosulfan', 'dose': '0.5L/acre', 'safety': 'Avoid inhalation'}
            ]
        },
        'Cotton': {
            'precautions': 'Rotate crops; monitor bollworms.',
            'marketing': 'High demand for textile industry.',
            'soil_health': 'Ensure nitrogen; add compost.',
            'fertilizers': [
                {'type': 'Urea', 'amount': '50kg/acre', 'timing': 'Sowing'},
                {'type': 'DAP', 'amount': '40kg/acre', 'timing': 'Flowering'},
                {'type': 'Potash', 'amount': '30kg/acre', 'timing': 'Boll formation'}
            ],
            'pesticides': [
                {'type': 'Cypermethrin', 'dose': '0.5ml/L', 'safety': 'Wear gloves'},
                {'type': 'Mancozeb', 'dose': '2g/L', 'safety': 'Avoid inhalation'}
            ]
        },
        'Jute': {
            'precautions': 'Ensure sandy loam soil; avoid water stagnation.',
            'marketing': 'Used in ropes and sacks; high local demand.',
            'soil_health': 'Maintain organic matter; pH 6-7.',
            'fertilizers': [
                {'type': 'NPK', 'amount': '60kg/acre', 'timing': 'Sowing'},
                {'type': 'Urea', 'amount': '40kg/acre', 'timing': 'Vegetative stage'}
            ],
            'pesticides': [
                {'type': 'Carbendazim', 'dose': '1g/L', 'safety': 'Wear gloves'},
                {'type': 'Chlorpyrifos', 'dose': '1L/acre', 'safety': 'Avoid direct contact'}
            ]
        },
        'Coffee': {
    'precautions': (
        'Plant coffee under partial shade; avoid waterlogging. '
        'Monitor for pests like coffee borer beetle, leaf rust, and aphids. '
        'Prune regularly to maintain airflow and reduce disease incidence. '
        'Mulch to conserve soil moisture and prevent weed growth.'
    ),
    'marketing': (
        'Coffee has high export potential and is in demand in specialty markets worldwide. '
        'Ensure beans are processed properly (washed, dried, or roasted) to maintain quality. '
        'Organic and specialty coffee varieties fetch higher market prices.'
    ),
    'soil_health': (
        'Maintain soil pH between 6.0 and 6.5. '
        'Enrich soil with organic matter like compost or well-rotted manure. '
        'Ensure good drainage and avoid compacted soils. '
        'Periodic soil testing is recommended to monitor nutrient levels.'
    ),
    'fertilizers': [
        {'type': 'NPK (20:10:10)', 'amount': '200g/plant/year', 'timing': 'Split into 3 applications: pre-flowering, fruit setting, post-harvest'},
        {'type': 'Compost', 'amount': '10-15kg/plant/year', 'timing': 'Apply around root zone before monsoon'},
        {'type': 'Urea', 'amount': '50g/plant', 'timing': 'Pre-flowering stage for nitrogen boost'}
    ],
    'pesticides': [
        {'type': 'Chlorpyrifos', 'dose': '2ml/L', 'safety': 'Wear gloves and mask; avoid inhalation'},
        {'type': 'Neem oil', 'dose': '5ml/L', 'safety': 'Safe for humans; avoid eye contact'},
        {'type': 'Carbendazim', 'dose': '1g/L', 'safety': 'Use gloves and avoid inhalation; for fungal infections'}
    ]
}

    }

    if request.method == 'POST':
        try:
            # Collect user inputs
            N = float(request.POST['N'])
            P = float(request.POST['P'])
            K = float(request.POST['K'])
            temperature = float(request.POST['temperature'])
            humidity = float(request.POST['humidity'])
            ph = float(request.POST['ph'])
            rainfall = float(request.POST['rainfall'])

            input_df = pd.DataFrame([[N, P, K, temperature, humidity, ph, rainfall]], columns=FEATURE_COLUMNS)

            model_path = 'crop_model.pkl'            
            if os.path.exists(model_path):
                model = joblib.load(model_path)
                prediction = model.predict(input_df)[0]
                predicted_crop = labels.get(prediction, "Unknown")

                details = crop_info.get(predicted_crop, {})

                # Extract crop details
                soil_health = details.get('soil_health', 'Soil health information not available.')
                fertilizers = details.get('fertilizers', [])
                pesticides = details.get('pesticides', [])
                precautions = details.get('precautions', 'No data available.')
                marketing = details.get('marketing', 'No data available.')

                # 🌱 Create descriptive recommendation content
                descriptive_summary = (
                    f"<h4>🌾 Crop Recommendation Summary</h4>"
                    f"<p>Based on your provided soil and environmental data — "
                    f"Nitrogen ({N}), Phosphorus ({P}), Potassium ({K}), "
                    f"Temperature ({temperature}°C), Humidity ({humidity}%), "
                    f"pH ({ph}), and Rainfall ({rainfall} mm) — "
                    f"the most suitable crop for your region is "
                    f"<strong>{predicted_crop}</strong>. 🌿</p>"
                    f"<p>This crop aligns well with your climatic and soil conditions, "
                    f"offering good yield stability, profitability, and sustainable soil balance.</p>"
                )

                # 🌾 Soil Health Description
                soil_health_description = (
                    f"<strong>🌱 Soil Health & Management:</strong> {soil_health} "
                    f"Healthy soil is the cornerstone of productive agriculture. "
                    f"Regular soil testing helps identify nutrient deficiencies. "
                    f"Your current soil pH is <strong>{ph}</strong>; maintaining it between 6.0–7.5 "
                    f"ensures most nutrients remain available for plant uptake. "
                    f"Enhance soil organic matter through compost or green manures."
                )

                # 🌿 Fertilizer Recommendations
                fertilizer_description = "<strong>💧 Fertilizer Management:</strong> "
                if fertilizers:
                    fert_list = "".join([
                        f"<li>• <strong>{f['type']}</strong> — {f['amount']} (Timing: {f['timing']}).</li>"
                        for f in fertilizers
                    ])
                    fertilizer_description += (
                        f"Balanced fertilization ensures better nutrient uptake and yield optimization. "
                        f"Follow the schedule below:<ul>{fert_list}</ul>"
                        f"Split nitrogen fertilizers like urea into two or three doses "
                        f"to minimize losses and improve efficiency."
                    )
                else:
                    fertilizer_description += "No fertilizer data available for this crop."

                # 🧪 Pesticide Recommendations
                pesticide_description = "<strong>🧪 Pest & Disease Control:</strong> "
                if pesticides:
                    pest_list = "".join([
                        f"<li>• <strong>{p['type']}</strong> — Apply {p['dose']} (Safety: {p['safety']}).</li>"
                        for p in pesticides
                    ])
                    pesticide_description += (
                        f"To safeguard against pests and fungal diseases, follow Integrated Pest Management (IPM) "
                        f"practices. Below are recommended treatments:<ul>{pest_list}</ul>"
                        f"Use protective gear during application and avoid overuse to protect beneficial soil microbes."
                    )
                else:
                    pesticide_description += "No pesticide data available for this crop."

                # ⚠️ Precautions
                precautions_description = (
                    f"<strong>⚠️ Crop Precautions:</strong> {precautions} "
                    f"Timely irrigation, pest monitoring, and proper crop spacing "
                    f"are essential for maintaining plant health and achieving high yields."
                )

                # 💰 Marketing
                marketing_description = (
                    f"<strong>💰 Marketing Insights:</strong> {marketing} "
                    f"Analyze local demand trends and connect with buyers through FPOs, cooperatives, or e-NAM. "
                    f"Maintaining post-harvest quality and grading standards can significantly improve market prices."
                )

                # 🌻 Final Recommendation Output
                return render(request, 'user_input.html', {
                    'recommended_crop': predicted_crop,
                    'description': descriptive_summary,
                    'soil_health_description': soil_health_description,
                    'fertilizer_description': fertilizer_description,
                    'pesticide_description': pesticide_description,
                    'precautions_description': precautions_description,
                    'marketing_description': marketing_description,
                })

            else:
                return render(request, 'user_input.html', {'error': '⚠️ Model not trained yet. Please upload crop_model.pkl.'})

        except Exception as e:
            return render(request, 'user_input.html', {'error': f'Error: {e}'})

    return render(request, 'user_input.html')




def logout(request):
    request.session.flush()
    return redirect('home')

from django.http import JsonResponse
from django.http import JsonResponse

def chatbot_response(request):
    if request.method == "POST":
        user_message = request.POST.get("message", "").lower().strip()

        responses = {
            # 🌱 General greetings
            "hello": "Hey there! 👋 I’m AgriBot — your friendly farm assistant. How’s your farm today?",
            "hi": "Hi farmer! 🌾 How can I help you grow better crops today?",
            "hey": "Hey 👩‍🌾, what’s growing on? Need advice on crops or soil?",
            "how are you": "I’m full of green energy 🌿! Hope your fields are doing great too.",
            "good morning": "Good morning ☀️! Wishing you a day full of healthy crops.",
            "good evening": "Good evening 🌇! How was your day on the farm?",
            "good night": "Good night 🌙. Remember to check soil moisture before resting!",

            # 🌾 Basic info
            "what is crop recommendation": "Crop recommendation means suggesting the best crop for your soil and weather conditions 🌱.",
            "what is npk": "NPK stands for Nitrogen (N), Phosphorus (P), and Potassium (K). They’re like the main nutrients or vitamins for your plants.",
            "nitrogen": "Nitrogen helps your plants grow strong leaves 🌿. Urea or compost can boost it naturally.",
            "phosphorus": "Phosphorus supports strong roots and better flowering 🌸. Try DAP or bone meal.",
            "potassium": "Potassium keeps crops healthy and improves yield 🍅. Muriate of Potash works well.",
            "ph value": "Soil pH shows how acidic or alkaline your soil is. Most crops prefer 6–7.",
            "improve soil ph": "If your soil is acidic, add lime. If too alkaline, use sulfur or organic compost.",

            # 🌦️ Weather and environment
            "temperature": "Each crop loves a different temperature. Rice likes 20–35°C, wheat 10–25°C 🌡️.",
            "humidity": "Humidity affects pest attacks and fungal growth. Keep it moderate for most crops.",
            "rainfall": "Rainfall affects irrigation planning. Too much = fungus risk, too little = stress.",
            "weather": "Always check local forecasts before spraying or sowing! IMD or Skymet apps help.",

            # 🌍 Soil & fertilizer management
            "soil health": "Healthy soil smells earthy, drains well, and has plenty of worms 🪱. Use compost often.",
            "soil test": "Do a soil test every 2 years to know NPK and pH. It helps you save fertilizer and money.",
            "fertilizer": "Fertilizers feed your crops — but balance is key. Too much hurts soil life.",
            "organic fertilizer": "Organic fertilizers like compost, manure, and neem cake keep soil fertile long-term.",
            "chemical fertilizer": "Use chemical fertilizers carefully — overuse can harden soil and reduce yield.",
            "vermicompost": "Vermicompost is made using earthworms. It’s like a superfood for your soil 🌿.",
            "green manure": "Green manure crops (like sunn hemp) add natural nitrogen when ploughed in.",
            "fertilizer timing": "Apply fertilizers after rain or irrigation so nutrients mix well in soil.",

            # 💧 Irrigation
            "irrigation": "Drip irrigation saves 40–50% water 💧. Sprinklers are good for small fields.",
            "drip irrigation": "Delivers water right to roots — great for vegetables and fruit crops.",
            "sprinkler irrigation": "Mimics natural rain and suits sandy soil.",
            "watering": "Best time to water? Early morning or evening 🌅.",
            "water saving": "Use mulching or drip irrigation to reduce evaporation and save water.",

            # 🌾 Crop information — more human style
            "best crop": "Tell me your soil NPK, temperature, humidity, rainfall, and pH — I’ll suggest the right crop 🌱.",
            "which crop is best": "Share your soil data and weather, and I’ll find your best crop match!",
            "rabi crops": "Rabi crops like wheat and mustard grow in winter ❄️.",
            "kharif crops": "Kharif crops like rice, maize, and cotton love the monsoon 🌧️.",
            "zaid crops": "Zaid crops (watermelon, cucumber) are grown between rabi and kharif seasons 🍉.",
            "monsoon crops": "Rice, maize, cotton, and soybeans thrive in the rainy season.",
            "winter crops": "Wheat, mustard, and peas prefer cooler weather.",
            "summer crops": "Sugarcane, groundnut, and millets grow best in hot months.",

            # 🌾 Crop-specific advice (Expanded)
            "rice": "Rice loves clay soil, standing water, and warm weather (25–35°C).",
            "wheat": "Wheat grows best in loamy soil and cool weather. Don’t overwater 🌾.",
            "maize": "Maize needs plenty of sunlight and moderate water 🌽.",
            "cotton": "Cotton likes black soil, warm days, and dry harvest weather 👕.",
            "sugarcane": "Sugarcane requires rich soil, heavy nutrients, and good drainage 🍬.",
            "banana": "Banana loves warm weather, loamy soil, and regular irrigation 🍌.",
            "tomato": "Tomatoes love sunlight and slightly acidic soil (pH ~6.5) 🍅.",
            "potato": "Potatoes prefer cool weather and sandy soil 🥔.",
            "chilli": "Chillies like warm, dry weather and well-drained soil 🌶️.",
            "onion": "Onions prefer cool growing and warm harvesting weather 🧅.",
            "groundnut": "Groundnut needs sandy soil and a dry harvest period 🌰.",
            "millet": "Millets are drought-resistant and perfect for dry regions 🌾.",
            "pulses": "Pulses improve soil fertility naturally — they fix nitrogen.",
            "soybean": "Soybean loves moderate rainfall and neutral pH soil.",
            "sunflower": "Sunflowers grow well in loamy soil and full sunlight 🌻.",
            "mustard": "Mustard grows best in cold climate with low rainfall.",
            "barley": "Barley thrives in light soil and needs less water.",
            "watermelon": "Watermelon loves sandy soil and hot weather 🍉.",
            "cucumber": "Cucumber grows well in loamy soil and warm climate 🥒.",
            "brinjal": "Brinjal loves warm weather and loamy soil 🍆.",
            "cabbage": "Cabbage needs cool weather and frequent watering 🥬.",
            "cauliflower": "Cauliflower prefers cool, humid climate with fertile soil.",
            "papaya": "Papaya grows fast in warm, frost-free areas 🍈.",
            "mango": "Mango trees thrive in tropical climate with good drainage 🥭.",
            "coconut": "Coconut palms love sandy soil and coastal humidity 🥥.",
            "pomegranate": "Pomegranate likes dry climate and well-drained soil 🍎.",
            "turmeric": "Turmeric needs warm, humid conditions and rich loamy soil 🟡.",
            "ginger": "Ginger likes shade, moisture, and soft loamy soil 🫚.",

            # 🌿 Crop care and yield
            "crop rotation": "Rotate crops to maintain soil fertility and reduce pests 🌾➡️🌽.",
            "yield improvement": "Use good seeds, balanced NPK, and timely irrigation for higher yield.",
            "disease": "Watch for yellowing leaves or spots — could be fungal disease.",
            "fungicide": "Use Mancozeb or organic alternatives like neem extract 🌿.",
            "pesticide": "Use only recommended pesticides. Overuse harms beneficial insects 🐝.",
            "pest control": "Try neem oil, cow urine, or biological control instead of heavy chemicals.",
            "insects": "Aphids, caterpillars, and borers are common. Early detection saves yield!",
            "weed control": "Use mulching or hand weeding regularly 🌱.",
            "mulching": "Mulch keeps soil moist and prevents weeds — use straw or dry leaves.",
            "organic farming": "Avoid chemicals, rely on compost and natural pest control 🌿.",
            "hydroponics": "Hydroponics = soil-free farming using nutrient water — great for small spaces.",
            "greenhouse": "Greenhouses protect crops from weather and insects 🌡️.",
            "climate change": "Use resilient crops, drip irrigation, and water harvesting to adapt 🌍.",

            # 🧑‍🌾 Government schemes & help
            "government schemes": "Check PM-Kisan, Soil Health Card, and FPO programs for support 💰.",
            "pm kisan": "PM-Kisan gives ₹6000 yearly to eligible farmers — 3 installments.",
            "soil health card": "It shows soil nutrient levels and fertilizer suggestions 🧾.",
            "crop insurance": "PMFBY covers crop losses due to flood, drought, or pests 🌦️.",
            "loan": "Kisan Credit Card gives easy crop loans at low interest 💳.",
            "training": "Visit Krishi Vigyan Kendra for free farm training near you.",
            "machinery": "FPOs and startups rent out tractors, sprayers, and harvesters 🚜.",

            # 🌾 Crop-wise fertilizer guide
            "fertilizer for rice": "Use Urea + DAP + MOP in 3 stages — tillering, panicle, grain fill.",
            "fertilizer for wheat": "Apply Urea and DAP at sowing, and once after 25 days 🌾.",
            "fertilizer for maize": "Use NPK 20:10:10; top-dress after tasseling 🌽.",
            "fertilizer for cotton": "NPK 4:2:1; add more potash during flowering 👕.",
            "fertilizer for sugarcane": "NPK 15:15:15; apply FYM before planting 🍬.",
            "fertilizer for tomato": "NPK 19:19:19 + compost = high quality fruit 🍅.",
            "fertilizer for banana": "FYM + NPK 8:10:8 every month keeps banana healthy 🍌.",
            "fertilizer for paddy": "NPK 12:32:16 with split doses works great for paddy fields 🌾.",
            "fertilizer for chilli": "NPK 30:10:10 and organic manure every 15 days 🌶️.",

            # 🌿 Pest management
            "pesticide for rice": "Use Chlorpyrifos or Neem oil for stem borer control.",
            "pesticide for wheat": "Imidacloprid helps control aphids in wheat.",
            "pesticide for tomato": "Spinosad or neem spray works for fruit borer 🍅.",
            "pesticide for cotton": "Use Profenofos for bollworm, rotate chemicals regularly.",
            "pesticide for maize": "Use Lambda-cyhalothrin for caterpillars 🌽.",
            "natural pesticide": "Try neem leaf spray or garlic-chilli mix as a bio-pesticide.",
            "storage pest": "Add neem leaves or dry chillies to stored grains for pest safety.",

            # 💰 Marketing & storage
            "marketing": "Sell directly to consumers or via FPOs for better profit 📈.",
            "sell crops": "Use eNAM or local mandis; early morning sales get better prices.",
            "storage": "Store produce in cool, dry areas with airflow to avoid fungus.",
            "transport": "Transport crops in shaded trucks to prevent spoilage 🚚.",
            "export": "Register with APEDA to export crops like mango or rice 🌎.",
            "profit": "Profit grows with better soil care, cost reduction, and timing.",
            "cost reduction": "Reduce chemicals; go organic for sustainable low-cost farming.",

            # 🧠 Extra knowledge & casual talk
            "who are you": "I’m AgriBot 🌿 — a friendly assistant helping you grow smarter!",
            "what can you do": "I can suggest fertilizers, soil tips, pest solutions, and government schemes.",
            "where are you from": "I live inside your Django app — totally offline 😄.",
            "thank you": "Anytime! 🙏 Wishing your crops a great harvest!",
            "thanks": "You’re very welcome 🌾.",
            "bye": "Goodbye 👋 Stay green and keep growing!",
        }

        response = "Hmm... I’m not sure I understood that 🌱. Try asking about soil, crops, fertilizer, or weather!"
        for key, val in responses.items():
            if key in user_message:
                response = val
                break

        return JsonResponse({"response": response})


        # Default fallback
        response = "I'm sorry, I didn’t quite understand that 🌱. Could you ask in another way?"
        for key, val in responses.items():
            if key in user_message:
                response = val
                break

        return JsonResponse({"response": response})
